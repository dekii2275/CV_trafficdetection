from services.road_services.AnalyzeOnRoadForMultiProcessing import AnalyzeOnRoadForMultiprocessing
# from services.ChatBotAgent import ChatBotAgent
from services import AnalyzeOnRoadForMultiProcessing


# Phần gắn tạm để gợi ý code
# analyzer = AnalyzeOnRoadForMultiprocessing(show= False,
#                                            show_log= False,
#                                            is_join_processes= False)
# agent = ChatBotAgent()


# Phần states chính thức
analyzer = None
# chat_bot = None
agent = None